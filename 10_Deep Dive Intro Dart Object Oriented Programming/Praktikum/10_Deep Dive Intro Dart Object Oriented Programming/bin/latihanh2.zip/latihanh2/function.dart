void hallo() {
  print('Hallo, Selamat pagi dunia');
}

void main() {
  hallo();
  hallo();
  tampil('Hallo');
  tampil('Selamat datang');
}

//function parameter
void tampil(String teks) {
  print(teks);
}
