void main() {
  for (var i = 0; i < 10; i += 3) {
    print(i);
  }
}
