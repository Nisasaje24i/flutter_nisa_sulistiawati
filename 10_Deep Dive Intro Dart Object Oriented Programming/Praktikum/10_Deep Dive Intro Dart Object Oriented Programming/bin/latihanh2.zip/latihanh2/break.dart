void main() {
  for (var i = 0; i < 10; i += 3) {
    if (i == 6) {
      break;
    }
    print(i);
  }
}
