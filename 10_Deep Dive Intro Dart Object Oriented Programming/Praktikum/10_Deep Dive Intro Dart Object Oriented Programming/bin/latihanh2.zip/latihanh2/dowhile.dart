void main() {
  var i = 1;
  do {
    print(i); //dijalankan minimal 1 kali
    i++;
  } while (i > 10);
}
