int jumlah(int a, int b) {
  return a + b;
}

void main() {
  var hasil = jumlah(1, 2);
  print(hasil);
}
