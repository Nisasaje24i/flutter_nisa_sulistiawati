package com.example.tugas_finite_state

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
