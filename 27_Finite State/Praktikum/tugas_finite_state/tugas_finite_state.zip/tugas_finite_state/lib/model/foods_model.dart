class Foods {
  final int id;
  final String name;

  Foods({required this.id, required this.name});
}
